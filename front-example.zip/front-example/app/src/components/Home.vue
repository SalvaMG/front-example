<template>
	<div class="rootDiv">
		<div class="sideNav">
				<div class="toolBar" @click="select(1)">
					<label class="toolBarLabel"> Vue d'ensemble</label>
				</div>
				<div class="toolBar" @click="select(2)">
					<label class="toolBarLabel">Statistiques de campagnes</label>
				</div>
				<div class="toolBar" @click="select(3)"> 
					<label class="toolBarLabel">Gestion budgétaire</label>
				</div>
				<div class="toolBar" @click="select(4)">
					<label class="toolBarLabel">Paramétrage</label>
				</div>

		</div>
		<div class="bodyNav">
			<div v-if="view==1"><GlobalView/></div>
			<div v-if="view==2"><Charts/></div>
			<div v-if="view==3"><FinancialManagement/></div>
			<div v-if="view==4"><Settings/></div>

		</div>
	</div>
</template>

<script>

import GlobalView from './datas/GlobalView'
import Charts from './datas/Charts'
import FinancialManagement from './datas/FinancialManagement'
import Settings from './datas/Settings'

export default {
	data: () => ({
      view:1
	}),
	components:{
		GlobalView,
		Charts,
		FinancialManagement,
		Settings
	},
	methods: {
        select: function(event) {
			console.log(event)
            this.view=event
        }
    }
}
</script>

<style>

.toolBar{
	display: flex;
    color: white;
    text-align: center;
    padding: 10px;
	height: 8%;
	box-shadow: 0 1px 7px rgba(0,0,0,0.16), 0 1px 1px rgba(0,0,0,0.23);
	margin: auto;
	cursor: pointer;
}

.toolBarLabel{
	font-weight: 600;
	margin-top: auto;
    margin-bottom: auto;
	cursor: pointer;
}


.rootDiv{
	display: flex;
}
.sideNav{
	width: 25%;
	padding-top: 5%;
	height: 100vh;
	background-color: #ff5252;
}

.bodyNav{
	width: 75%;
}

</style>