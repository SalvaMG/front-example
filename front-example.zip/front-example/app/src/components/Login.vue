<template>
  <div class="loginDiv">
    <div class="rightDiv">
<img width=100 src="../assets/dr_logo.png">
      <md-field>
        <label>Email*</label>
        <md-input v-model="login"></md-input>
      </md-field>  

      <md-field>
        <label>Mot de passe*</label>
        <md-input v-model="pwd" type="password"></md-input>
      </md-field>                    
      <md-button v-on:click="validate" class="md-raised md-accent connect">Se connecter</md-button>
      <md-snackbar :md-active.sync="showSnackbar" :md-duration="4000" md-persistent>
        <span>Vos indentifiants sont erronés</span>
        <md-button class="md-primary"  @click="showSnackbar = false">Fermer</md-button>
    </md-snackbar>
    </div>
  </div>
</template>

<script>
export default {
    name: 'TextFields',
    data: () => ({
      login: '',
      pwd:'',
      showSnackbar:false
    }),
  methods: {
    validate : function (){
      if (this.login == 'admin' && this.pwd=='hello'){
        console.log('')
        this.$router.push({ name: 'Home' })
      }else{
        this.showSnackbar = true
      }
    }
  }
}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.rightDiv {
  width: 40%;
  background-color: white;
  height: 70%;
  padding: 5%;
  opacity: 0.9;
  margin-left: 30%;
  margin-right: 30%;
}

.loginDiv {
  background-image: url("../assets/business.jpg");
  padding: 5%;
  height: 100%;
  background-position: left;
  background-color: black;
}

h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
