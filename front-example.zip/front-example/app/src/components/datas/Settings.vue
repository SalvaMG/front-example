<template>
		<div>
			<h1 class="financialTitle">Gestion budgétaire des campagnes</h1>

			<md-card>
				<md-card-header>
					<div class="md-title">Leroy Merlin</div>
				</md-card-header>

				<md-card-content>
					<md-switch v-model="lm.fb">Facebook</md-switch>
					<md-switch v-model="lm.ga">Google Ads</md-switch>
					<md-checkbox v-model="lm.tr">Envoi du reporting</md-checkbox>
				</md-card-content>

				<md-card-actions>
					
				</md-card-actions>
			</md-card>

			<md-card>
				<md-card-header>
					<div class="md-title">Castorama</div>
				</md-card-header>

				<md-card-content>
					<md-switch v-model="ca.fb" >Facebook</md-switch>
					<md-switch v-model="ca.ga" >Google Ads</md-switch>
					<md-checkbox v-model="ca.tr">Envoi du reporting</md-checkbox>
				</md-card-content>

				
			</md-card>

			<md-card>
				<md-card-header>
					<div class="md-title">Brico Depôt</div>
				</md-card-header>

				<md-card-content>
					<md-switch v-model="bd.fb" >Facebook</md-switch>
					<md-switch v-model="bd.ga" >Google Ads</md-switch>
					<md-checkbox v-model="bd.tr">Envoi du reporting</md-checkbox>
				</md-card-content>

			</md-card>

			<md-card>
				<md-card-header>
					<div class="md-title">Mr Bricolage</div>
				</md-card-header>

				<md-card-content>
					<md-switch v-model="mr.fb" >Facebook</md-switch>
					<md-switch v-model="mr.ga" >Google Ads</md-switch>
					<md-checkbox v-model="mr.tr">Envoi du reporting</md-checkbox>
				</md-card-content>

			
			</md-card>

			
		</div>
</template>

	<script>
		export default {
			name: 'RegularCards',
			data: () => ({
				lm:{fb:true, ga:false, tr:true},
				bd:{fb:false, ga:true, tr:true},
				mr:{fb:true, ga:true, tr:false},
				ca:{fb:true, ga:false, tr:true}
			})


		}
	</script>


	<style scoped>

		.financialTitle{
			margin: 5%;
		}

		.md-card {
			width: 320px;
			margin: 4px;
			display: inline-block;
			vertical-align: top;
		}
	</style>

		