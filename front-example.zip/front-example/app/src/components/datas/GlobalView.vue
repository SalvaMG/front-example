<template>
	<div class="globalDiv">

		<md-table  class="globalTable" v-model="searched" md-sort="name" md-sort-order="asc" md-card md-fixed-header>
		<md-table-toolbar>
			<div class="md-toolbar-section-start">
			<h1 class="md-title">Vue globale des clients</h1>
			</div>

			<md-field md-clearable class="md-toolbar-section-end">
			<md-input placeholder="Filtrer par nom..." v-model="search" @input="searchOnTable" />
			</md-field>
		</md-table-toolbar>

		<md-table-empty-state
			md-label="Pas de client trouvé"
			:md-description="`Aucun clien trouvé avec '${search}' comme nom. Essayez avec une nouvelle recherche ou créez un nouveau client.`">
			<md-button class="md-primary md-raised" @click="newUser">Créer un nouveau clien</md-button>
		</md-table-empty-state>

		<md-table-row slot="md-table-row" slot-scope="{ item }">
			<md-table-cell md-label="ID" md-sort-by="id" md-numeric>{{ item.id }}</md-table-cell>
			<md-table-cell md-label="Nom" md-sort-by="name">{{ item.name }}</md-table-cell>
			<md-table-cell md-label="Nombre de campagnes" >{{ item.campains }}</md-table-cell>
			<md-table-cell md-label="Localisations" >{{ item.localisations }}</md-table-cell>
			<md-table-cell md-label="Budget" >{{ item.budget }}</md-table-cell>

		</md-table-row>
		</md-table>
	</div>
</template>

<script>
	const toLower = text => {
		return text.toString().toLowerCase()
	}

	const searchByName = (items, term) => {
		if (term) {
		return items.filter(item => toLower(item.name).includes(toLower(term)))
		}

		return items
	}

	export default {
		name: 'TableSearch',
		data: () => ({
		search: null,
		searched: [],
		users: [
			{
			id: 1,
			name: "Leroy Merlin",
			campains: "56",
			localisations: "140",
			budget:"100000"
			},
			{
			id: 2,
			name: "Castorama",
			campains: "34",
			localisations: "32",
			budget:"18000"
			},
			{
			id: 3,
			name: "Bricodepot",
			campains: "8",
			localisations: "21",
			budget:"40000"
			},
			{
			id: 4,
			name: "Mr Bricolage",
			campains: "10",
			localisations: "18",
			budget:"20000"
			}
		]
		}),
		methods: {
			newUser () {
				window.alert('Noop')
			},
			searchOnTable () {
				this.searched = searchByName(this.users, this.search)
			}
		},
		created () {
			this.searched = this.users
		}
	}
</script>

<style>
.globalDiv{
	width: 100%;
}

.globalTable{
	margin-top: 5%;
}
</style>