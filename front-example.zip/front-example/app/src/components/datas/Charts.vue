<template>
			<div>
				<h1>Comparatif du CpC</h1>
				<div class="small">
					<line-chart :chart-data="datacollection"></line-chart>
					<md-button class="md-raised md-accent connect" @click="fillData()">Randomize</md-button>
				</div>
			</div>
</template>

<script>
	import LineChart from './LineChart.js'

	export default {
		components: {
		LineChart
		},
		data () {
			
		return {
			datacollection: null,
			w:this.getRandomInt(),
			x:this.getRandomInt(),
			y:this.getRandomInt(),
			z:this.getRandomInt()
		}
		},
		mounted () {
		this.fillData()
		},
		methods: {
		fillData () {
			this.w=this.getRandomInt();
			this.x=this.getRandomInt();
			this.y=this.getRandomInt();
			this.z=this.getRandomInt();

			this.datacollection = {
			labels: [ '1er trimestre','2nd trimestre','3nd trimestre', '4ème trimestre'],
			datasets: [
				{
				label: '2019',
				backgroundColor: '#ff5252',
				data: [this.w,this.x, this.y, this.z]
				}, {
				label: '2020',
				backgroundColor: '#448aff',
				data: [this.w+0.5,this.x+1, this.y+2, this.z+1]
				}
			]
			}
		},
		getRandomInt () {
			return Math.floor(Math.random() * 10) + 2
		}
		}
	}
</script>

<style>
  .small {
	margin: auto;
    max-width: 50%;
	max-height: 50%;
  }
</style>