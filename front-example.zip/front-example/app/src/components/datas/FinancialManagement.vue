	<template>
	<div>
		<h1 class="financialTitle">Gestion budgétaire des campagnes</h1>

		<md-card>
			<md-card-header>
				<div class="md-title">Leroy Merlin</div>
			</md-card-header>

			<md-card-content>
				<label> {{lm}}€</label>
			</md-card-content>

			<md-card-actions>
				<md-button v-on:click="lm=lm+1000">Augmenter</md-button>
				<md-button v-on:click="lm=0">Arrêter</md-button>
			</md-card-actions>
		</md-card>

		<md-card>
			<md-card-header>
				<div class="md-title">Castorama</div>
			</md-card-header>

			<md-card-content>
				<label> {{ca}}€</label>
			</md-card-content>

			<md-card-actions>
				<md-button v-on:click="ca=ca+1000">Augmenter</md-button>
				<md-button v-on:click="ca=0">Arrêter</md-button>
			</md-card-actions>
		</md-card>

		<md-card>
			<md-card-header>
				<div class="md-title">Brico Depôt</div>
			</md-card-header>

			<md-card-content>
				<label> {{bd}}€</label>
			</md-card-content>

			<md-card-actions>
				<md-button v-on:click="bd=bd+1000">Augmenter</md-button>
				<md-button v-on:click="bd=0">Arrêter</md-button>
			</md-card-actions>
		</md-card>

		<md-card>
			<md-card-header>
				<div class="md-title">Mr Bricolage</div>
			</md-card-header>

			<md-card-content>
				<label> {{mr}}€</label>
			</md-card-content>

			<md-card-actions>
		<md-button v-on:click="mr=mr+1000">Augmenter</md-button>
				<md-button v-on:click="mr=0">Arrêter</md-button>
			</md-card-actions>
		</md-card>

		
	</div>
</template>

<script>
	export default {
		name: 'RegularCards',
		data: () => ({
			lm:10000,
			bd:5000,
			mr:4000,
			ca:9000
		})


	}
</script>


<style scoped>

	.financialTitle{
		margin: 5%;
	}

	.md-card {
		width: 320px;
		margin: 4px;
		display: inline-block;
		vertical-align: top;
	}
</style>

	